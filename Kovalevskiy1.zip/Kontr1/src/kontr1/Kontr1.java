/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kontr1;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author pupil
 */
public class Kontr1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String q = "r";
        while ("r".equals(q)) {
            System.out.println("-----------Начало новой игры-----------");
            int approach = 0;
            Random random = new Random();
            Scanner scanner = new Scanner(System.in);
            int number = random.nextInt(10);
            System.out.println("Компьютер загадал число от 0 до 9, попробуйте его отгдать");
            System.out.print("Введите кол-во попыток: ");
            int attemps = scanner.nextInt();
            System.out.println(number);
            while (attemps > 0) {
                approach = approach + 1;
                attemps = attemps - 1;
                System.out.print("Введите число: ");
                int answer = scanner.nextInt();
                if (answer == number) {
                    System.out.println("Правильно, ответ был: " + number + "\nВы отгадали с: " + approach + " раз(a)");
                    break;
                } else {
                    System.out.println("Неправильно, попробуй еще раз");
                    System.out.println("У вас осталось:" + attemps + " попыток" + "");
                }
                if (attemps == 0) {
                    System.out.println("Вы не смогли отгадать число, у вас осталось 0 попыток");
                }
            }
            System.out.print("Чтобы продолжить игру введи символ\"r\" и нажмите \"Enter\",\nЧтобы закончить программу нажми\"q\": ");
            q = scanner.next();
            System.out.println("Окончание игры.");

        }
    }
}
